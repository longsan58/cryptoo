
import * as React from 'react';
import type { User, KycRequest, PendingDeposit, Notification, UserDetails, KYCData, SystemSettings, PendingWithdrawal, SecondContractTrade, Transaction, UserStatus } from '../types.ts';
import { apiLogin, apiSignup, apiGetUserByToken, apiDeposit, apiSubmitKyc, apiWithdraw, apiGetAllUsers, apiGetPendingKyc, apiUpdateKycStatus, apiGetPendingDeposits, apiUpdateDepositStatus, apiMarkAllNotificationsAsRead, apiMarkNotificationAsRead, apiGetSystemSettings, apiGetPendingWithdrawals, apiUpdateWithdrawalStatus, apiAdminCreateUser, apiUpdateUserBalance, apiAddManualTransaction, apiGetAllTrades, apiVerifyAdminPassword, apiChangePassword, apiPlaceSecondContractTrade, apiCompleteSecondContractTrade, apiGetAllActiveContracts, apiAdminResolveContract, apiUpdateSystemSettings, apiAdminUpdateUser } from '../server/api.ts';

const AUTH_TOKEN_KEY = 'nisaAuthToken';

interface DepositDetails {
    amount: number;
    network: 'TRC20' | 'ERC20' | 'BTC';
    asset: string;
    transactionProof: string; // base64
}

interface WithdrawDetails {
    amount: number;
    address: string;
    asset: string;
}

interface PlaceSecondContractTradeDetails {
    amount: number;
    type: 'buy' | 'sell';
    option: {
        duration: number;
        profitRate: number;
        commissionRate: number;
    };
    entryPrice: number;
}

interface AuthContextType {
  user: User | null;
  isLoggedIn: boolean;
  isInitialized: boolean;
  isLoading: boolean;
  isAdmin: boolean;
  login: (email: string, password: string, loginInfo: { userAgent: string }) => Promise<void>;
  signup: (name: string, email: string, password: string, details: UserDetails, referralCode?: string) => Promise<void>;
  logout: () => void;
  deposit: (details: DepositDetails) => Promise<void>;
  updateUserPhoto: (photoFile: File) => Promise<void>;
  submitKyc: (kycData: KYCData) => Promise<void>;
  withdraw: (loginPassword: string, details: WithdrawDetails) => Promise<void>;
  markAllNotificationsAsRead: () => Promise<void>;
  markNotificationAsRead: (notificationId: string) => Promise<void>;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
  
  // New Second Contract Trading
  placeSecondContractTrade: (details: PlaceSecondContractTradeDetails) => Promise<void>;
  completeSecondContractTrade: (tradeId: string, currentPrice: number) => Promise<void>;

  // New Security
  changePassword: (currentPassword: string, newPassword: string) => Promise<void>;

  // System
  getSystemSettings: () => Promise<SystemSettings>;

  // Admin functions
  verifyAdminPassword: (password: string) => Promise<boolean>;
  fetchAllUsers: () => Promise<User[]>;
  fetchPendingKyc: () => Promise<KycRequest[]>;
  updateKycStatus: (password: string, targetUserId: string, status: 'verified' | 'rejected') => Promise<void>;
  fetchPendingDeposits: () => Promise<PendingDeposit[]>;
  updateDepositStatus: (password: string, targetUserId: string, transactionId: string, status: 'Completed' | 'Failed') => Promise<void>;
  fetchPendingWithdrawals: () => Promise<PendingWithdrawal[]>;
  updateWithdrawalStatus: (password: string, targetUserId: string, transactionId: string, status: 'Completed' | 'Failed') => Promise<void>;
  adminCreateUser: (details: {name: string, email: string, password?: string}) => Promise<void>;
  updateUserBalance: (password: string, targetUserId: string, newBalance: number) => Promise<void>;
  addManualTransaction: (password: string, details: { userEmail: string; type: 'Deposit' | 'Withdrawal'; asset: string; amount: number; }) => Promise<void>;
  getAllTrades: () => Promise<Transaction[]>;
  getAllActiveContracts: () => Promise<SecondContractTrade[]>;
  adminResolveContract: (password: string, tradeId: string, resolution: 'win' | 'loss') => Promise<void>;
  updateSystemSettings: (password: string, newSettings: SystemSettings) => Promise<void>;
  adminUpdateUser: (password: string, targetUserId: string, updates: { isAdmin?: boolean; status?: UserStatus }) => Promise<void>;
}

const AuthContext = React.createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = React.useState<User | null>(null);
  const [token, setToken] = React.useState<string | null>(null);
  const [isInitialized, setIsInitialized] = React.useState<boolean>(false);
  const [isLoading, setIsLoading] = React.useState<boolean>(false);
  const [isAdmin, setIsAdmin] = React.useState<boolean>(false);

  React.useEffect(() => {
    const rehydrateSession = async () => {
      try {
        const storedToken = localStorage.getItem(AUTH_TOKEN_KEY);
        if (storedToken) {
          const fetchedUser = await apiGetUserByToken(storedToken);
          const storedPhoto = localStorage.getItem(`nisaPhoto-${fetchedUser.uid}`);
          if (storedPhoto) fetchedUser.photoURL = storedPhoto;
          setUser(fetchedUser);
          setToken(storedToken);
          setIsAdmin(fetchedUser.isAdmin || false);
        }
      } catch (error) {
        console.error("Session rehydration failed:", error);
        localStorage.removeItem(AUTH_TOKEN_KEY);
      } finally {
        setIsInitialized(true);
      }
    };
    rehydrateSession();
  }, []);
  
  const login = async (email: string, password: string, loginInfo: { userAgent: string }) => {
    setIsLoading(true);
    try {
      const { user: loggedInUser, token: new_token } = await apiLogin(email, password, loginInfo);
      const storedPhoto = localStorage.getItem(`nisaPhoto-${loggedInUser.uid}`);
      if (storedPhoto) loggedInUser.photoURL = storedPhoto;
      setUser(loggedInUser);
      setToken(new_token);
      setIsAdmin(loggedInUser.isAdmin || false);
      localStorage.setItem(AUTH_TOKEN_KEY, new_token);
    } catch (error) {
       console.error("Login failed:", error); throw error;
    } finally {
      setIsLoading(false);
    }
  };
  
  const signup = async (name: string, email: string, password: string, details: UserDetails, referralCode?: string) => {
    setIsLoading(true);
    try {
        const { user: signedUpUser, token: new_token } = await apiSignup(name, email, password, details, referralCode);
        setUser(signedUpUser);
        setToken(new_token);
        setIsAdmin(signedUpUser.isAdmin || false);
        localStorage.setItem(AUTH_TOKEN_KEY, new_token);
    } catch(error) {
        console.error("Signup failed:", error); throw error;
    } finally {
        setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null); setToken(null); setIsAdmin(false);
    localStorage.removeItem(AUTH_TOKEN_KEY);
  };
  
  const deposit = async (details: DepositDetails) => {
      if(!token) throw new Error("Not authenticated");
      setIsLoading(true);
      try {
          const updatedUser = await apiDeposit(token, details);
          setUser(prevUser => prevUser ? {...prevUser, ...updatedUser} : updatedUser);
      } catch (error) {
          console.error("Deposit failed:", error); throw error;
      } finally {
          setIsLoading(false);
      }
  };

  const submitKyc = async (kycData: KYCData) => {
      if(!token) throw new Error("Not authenticated");
      setIsLoading(true);
      try {
        const updatedUser = await apiSubmitKyc(token, kycData);
        setUser(prevUser => prevUser ? {...prevUser, ...updatedUser} : updatedUser);
      } catch (error) {
        console.error("KYC Submission failed:", error); throw error;
      } finally {
        setIsLoading(false);
      }
  };
  
  const withdraw = async (loginPassword: string, details: WithdrawDetails) => {
      if(!token) throw new Error("Not authenticated");
      setIsLoading(true);
      try {
        const updatedUser = await apiWithdraw(token, loginPassword, details);
        setUser(prevUser => prevUser ? {...prevUser, ...updatedUser} : updatedUser);
      } catch (error) {
        console.error("Withdrawal failed:", error); throw error;
      } finally {
        setIsLoading(false);
      }
  };
  
  const placeSecondContractTrade = async (details: PlaceSecondContractTradeDetails) => {
      if(!token) throw new Error("Not authenticated");
      try {
        const updatedUser = await apiPlaceSecondContractTrade(token, details);
        setUser(updatedUser);
      } catch (error) {
        console.error("Trade placement failed:", error); throw error;
      }
  };
  
  const completeSecondContractTrade = async (tradeId: string, currentPrice: number) => {
      if(!token) throw new Error("Not authenticated");
      try {
        const updatedUser = await apiCompleteSecondContractTrade(token, tradeId, currentPrice);
        setUser(updatedUser);
      } catch (error) {
        console.error("Trade completion failed:", error); throw error;
      }
  };

  const updateUserPhoto = (photoFile: File): Promise<void> => {
    return new Promise((resolve, reject) => {
      if (!user) return reject(new Error("User not authenticated"));
      setIsLoading(true);
      const reader = new FileReader();
      reader.readAsDataURL(photoFile);
      reader.onload = () => {
        const dataUrl = reader.result as string;
        localStorage.setItem(`nisaPhoto-${user.uid}`, dataUrl);
        setUser(prevUser => (prevUser ? { ...prevUser, photoURL: dataUrl } : null));
        setIsLoading(false);
        resolve();
      };
      reader.onerror = error => { setIsLoading(false); reject(error); };
    });
  };

  const markAllNotificationsAsRead = async () => {
      if(!token) throw new Error("Not authenticated");
      setIsLoading(true);
      try {
          const updatedUser = await apiMarkAllNotificationsAsRead(token);
          setUser(prevUser => prevUser ? {...prevUser, ...updatedUser} : updatedUser);
      } catch (error) {
          console.error("Failed to mark all notifications as read:", error); throw error;
      } finally {
          setIsLoading(false);
      }
  };

  const markNotificationAsRead = async (notificationId: string) => {
    if(!token) throw new Error("Not authenticated");
    try {
        const updatedUser = await apiMarkNotificationAsRead(token, notificationId);
        setUser(prevUser => prevUser ? {...prevUser, ...updatedUser} : updatedUser);
    } catch (error) {
        console.error(`Failed to mark notification ${notificationId} as read:`, error); throw error;
    }
  };
  
  const changePassword = async (currentPassword: string, newPassword: string) => {
      if(!token) throw new Error("Not authenticated");
      setIsLoading(true);
      try {
          const updatedUser = await apiChangePassword(token, currentPassword, newPassword);
          setUser(prevUser => prevUser ? {...prevUser, ...updatedUser} : updatedUser);
      } catch (error) { throw error; } finally { setIsLoading(false); }
  };

  const fetchAllUsers = async (): Promise<User[]> => {
    if (!token) throw new Error("Not authenticated");
    return apiGetAllUsers(token);
  };
  const fetchPendingKyc = async (): Promise<KycRequest[]> => {
    if (!token) throw new Error("Not authenticated");
    return apiGetPendingKyc(token);
  };
  const updateKycStatus = async (password: string, targetUserId: string, status: 'verified' | 'rejected'): Promise<void> => {
    if(!token) throw new Error("Not authenticated");
    await apiUpdateKycStatus(token, password, targetUserId, status);
  };
  const fetchPendingDeposits = async (): Promise<PendingDeposit[]> => {
    if (!token) throw new Error("Not authenticated");
    return apiGetPendingDeposits(token);
  };
  const updateDepositStatus = async (password: string, targetUserId: string, transactionId: string, status: 'Completed' | 'Failed'): Promise<void> => {
      if(!token) throw new Error("Not authenticated");
      await apiUpdateDepositStatus(token, password, targetUserId, transactionId, status);
  };
  const fetchPendingWithdrawals = async (): Promise<PendingWithdrawal[]> => {
    if (!token) throw new Error("Not authenticated");
    return apiGetPendingWithdrawals(token);
  };
  const updateWithdrawalStatus = async (password: string, targetUserId: string, transactionId: string, status: 'Completed' | 'Failed'): Promise<void> => {
    if(!token) throw new Error("Not authenticated");
    await apiUpdateWithdrawalStatus(token, password, targetUserId, transactionId, status);
  };
  const verifyAdminPassword = async (password: string): Promise<boolean> => {
    if(!token) throw new Error("Not authenticated");
    return apiVerifyAdminPassword(token, password);
  }
  const updateUserBalance = async (password: string, targetUserId: string, newBalance: number) => {
    if(!token) throw new Error("Not authenticated");
    await apiUpdateUserBalance(token, password, targetUserId, newBalance);
  };
  const adminCreateUser = async (details: {name: string, email: string, password?: string}) => {
    if(!token) throw new Error("Not authenticated");
    await apiAdminCreateUser(token, details);
  };
  const addManualTransaction = async (password: string, details: { userEmail: string; type: 'Deposit' | 'Withdrawal'; asset: string; amount: number; }) => {
    if(!token) throw new Error("Not authenticated");
    await apiAddManualTransaction(token, password, details);
  };
  const getAllTrades = async (): Promise<Transaction[]> => {
    if(!token) throw new Error("Not authenticated");
    return apiGetAllTrades(token);
  };
  const getAllActiveContracts = async(): Promise<SecondContractTrade[]> => {
    if(!token) throw new Error("Not authenticated");
    return apiGetAllActiveContracts(token);
  }
  const adminResolveContract = async (password: string, tradeId: string, resolution: 'win' | 'loss') => {
    if(!token) throw new Error("Not authenticated");
    await apiAdminResolveContract(token, password, tradeId, resolution);
  }
  const updateSystemSettings = async (password: string, newSettings: SystemSettings) => {
    if(!token) throw new Error("Not authenticated");
    await apiUpdateSystemSettings(token, password, newSettings);
  };
  const adminUpdateUser = async (password: string, targetUserId: string, updates: { isAdmin?: boolean; status?: UserStatus }) => {
    if(!token) throw new Error("Not authenticated");
    await apiAdminUpdateUser(token, password, targetUserId, updates);
  };


  const value: AuthContextType = {
    user, isLoggedIn: !!user, isInitialized, isLoading, isAdmin,
    login, signup, logout, deposit, updateUserPhoto, submitKyc, withdraw,
    markAllNotificationsAsRead, markNotificationAsRead,
    setUser, placeSecondContractTrade, completeSecondContractTrade,
    changePassword,
    getSystemSettings: apiGetSystemSettings,
    // Admin
    verifyAdminPassword, fetchAllUsers, fetchPendingKyc, updateKycStatus,
    fetchPendingDeposits, updateDepositStatus, fetchPendingWithdrawals,
    updateWithdrawalStatus, adminCreateUser, updateUserBalance,
    addManualTransaction, getAllTrades, getAllActiveContracts, adminResolveContract,
    updateSystemSettings, adminUpdateUser,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = React.useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};