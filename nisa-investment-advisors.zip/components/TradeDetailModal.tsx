

import * as React from 'react';
import { X } from 'lucide-react';
import type { Transaction } from '../types.ts';

interface TradeDetailModalProps {
    isOpen: boolean;
    onClose: () => void;
    trade: Transaction | null;
}

const TradeDetailModal = ({ isOpen, onClose, trade }: TradeDetailModalProps) => {
    if (!isOpen || !trade) return null;

    const formatDate = (isoString?: string) => {
        if (!isoString) return 'N/A';
        const date = new Date(isoString);
        return date.toLocaleString('en-US', {
            year: 'numeric', month: '2-digit', day: '2-digit',
            hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
        }).replace(',', '');
    };

    const DetailRow = ({ label, value, valueColor = 'text-white' }: { label: string; value: string | number; valueColor?: string; }) => (
        <div className="flex justify-between items-center py-2 border-b border-slate-800">
            <span className="text-gray-400">{label}</span>
            <span className={`font-semibold ${valueColor}`}>{value}</span>
        </div>
    );
    
    const isWin = (trade.profit ?? 0) >= 0;

    return (
        <div className="fixed inset-0 bg-black/70 z-[100] flex items-center justify-center animate-fade-in-fast" onClick={onClose}>
            <div className="bg-slate-900 text-white rounded-lg p-6 w-full max-w-md mx-4 border border-slate-800" onClick={e => e.stopPropagation()}>
                <header className="flex justify-center items-center relative pb-4 border-b border-slate-800">
                    <h2 className="text-xl font-semibold">Trade Details</h2>
                     <button onClick={onClose} className="absolute right-0 p-1 text-gray-400 hover:text-white">
                        <X size={24} />
                    </button>
                </header>
                
                <main className="mt-4 space-y-2 text-sm">
                    <DetailRow label="Asset" value={trade.pair ?? 'N/A'} />
                    <DetailRow label="Direction" value={trade.direction ?? 'N/A'} valueColor={trade.direction === 'Buy' ? 'text-green-500' : 'text-red-500'} />
                    <DetailRow label="Status" value={isWin ? 'Win' : 'Loss'} valueColor={isWin ? 'text-green-500' : 'text-red-500'} />
                    <DetailRow label="Stake" value={`$${trade.stake?.toLocaleString() ?? 'N/A'}`} />
                    <DetailRow label="Profit/Loss" value={`$${trade.profit?.toFixed(2) ?? 'N/A'}`} valueColor={isWin ? 'text-green-500' : 'text-red-500'}/>
                    <DetailRow label="Entry Price" value={trade.entryPrice?.toFixed(4) ?? 'N/A'} />
                    <DetailRow label="Exit Price" value={trade.exitPrice?.toFixed(4) ?? 'N/A'} />
                    <DetailRow label="Commission" value={`$${trade.commission?.toFixed(2) ?? 'N/A'}`} />
                    <DetailRow label="Profit Rate" value={`${trade.profitPercentage?.toFixed(0) ?? 'N/A'}%`} />
                    <DetailRow label="Start Time" value={formatDate(trade.date)} />
                    <DetailRow label="End Time" value={formatDate(trade.endTime)} />
                </main>
            </div>
        </div>
    );
};

export default TradeDetailModal;