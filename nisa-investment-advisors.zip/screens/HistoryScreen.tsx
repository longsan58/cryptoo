
import * as React from 'react';
import type { Transaction } from '../types.ts';
import { useAuth } from '../contexts/AuthContext.tsx';
import TradeDetailModal from '../components/TradeDetailModal.tsx';
import { Wallet, ChevronRight } from 'lucide-react';

const HistoryScreen = () => {
    const [activeTab, setActiveTab] = React.useState('History');
    const { user } = useAuth();
    const [selectedTrade, setSelectedTrade] = React.useState<Transaction | null>(null);
    
    const tradeHistory = React.useMemo(() => {
        if (!user || !user.transactions) return [];
        return user.transactions
            .filter((tx): tx is Transaction & { type: 'Trade' } => tx.type === 'Trade')
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }, [user]);

    const formatDate = (isoString: string) => {
        if (!isoString) return 'N/A';
        const date = new Date(isoString);
        return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit'});
    };

    const HistoryListItem = ({ trade }: { trade: Transaction }) => {
        const isProfit = (trade.profit || 0) >= 0;
        const profitLossColor = isProfit ? 'text-green-500' : 'text-red-500';
        const directionColor = trade.direction === 'Buy' ? 'text-green-500' : 'text-red-500';
        
        return (
            <button 
                onClick={() => setSelectedTrade(trade)}
                className="w-full grid grid-cols-3 items-center py-4 border-b border-slate-800 hover:bg-slate-900 transition-colors duration-150"
            >
                <div className="text-left">
                    <p className="font-bold text-white">{trade.pair}</p>
                    <p className="text-xs text-gray-500 mt-1">{formatDate(trade.date)}</p>
                </div>

                <div className="text-center">
                    <p className={`font-semibold ${directionColor}`}>{trade.direction}</p>
                    <p className="text-sm text-gray-400">${trade.stake}</p>
                </div>

                <div className="text-right">
                    <p className={`text-lg font-bold ${profitLossColor}`}>{trade.profit?.toFixed(2)}</p>
                </div>
            </button>
        );
    }
    
    const pnl = 125.60; // Mock P&L
    const pnlPercentage = 1.5; // Mock P&L percentage

    return (
        <div className="min-h-screen">
            <header className="pt-6 pb-4">
                <h1 className="text-2xl font-bold text-center">Assets</h1>
            </header>

            {/* Asset Summary */}
            <div className="px-4 my-4">
                 <div className="bg-slate-900 p-6 rounded-2xl shadow-lg text-white">
                    <p className="text-sm font-medium opacity-80">Total Assets (USD)</p>
                    <p className="text-4xl font-bold mt-2">${user?.portfolio.balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2})}</p>
                    <div className="mt-2 text-sm">
                        <span className="opacity-80">Today's P&L </span>
                        <span className={`font-semibold ${pnl >= 0 ? 'text-green-300' : 'text-red-300'}`}>
                            {pnl >= 0 ? '+' : ''}${pnl.toFixed(2)} ({pnl >= 0 ? '+' : ''}{pnlPercentage.toFixed(2)}%)
                        </span>
                    </div>
                </div>
            </div>

            {/* Navigation Tabs */}
            <nav className="flex justify-around border-b border-slate-700/50">
                <button
                    onClick={() => setActiveTab('Positions')}
                    className={`px-6 py-3 font-semibold transition-colors ${activeTab === 'Positions' ? 'text-white border-b-2 border-purple-500' : 'text-gray-500'}`}
                >
                    Positions
                </button>
                <button
                    onClick={() => setActiveTab('History')}
                    className={`px-6 py-3 font-semibold transition-colors ${activeTab === 'History' ? 'text-white border-b-2 border-purple-500' : 'text-gray-500'}`}
                >
                    History
                </button>
            </nav>

            {/* Transaction List */}
            <main className="px-4 pb-24">
                {activeTab === 'History' ? (
                     tradeHistory.length > 0 ? (
                        <div>
                             <div className="grid grid-cols-3 text-sm text-gray-500 py-2">
                                <span className="text-left">Pair</span>
                                <span className="text-center">Type/Amount</span>
                                <span className="text-right">P&L</span>
                             </div>
                            {tradeHistory.map(trade => <HistoryListItem key={trade.id} trade={trade} />)}
                        </div>
                    ) : (
                        <div className="text-center py-20 text-gray-500">
                            <p>No trade history found.</p>
                        </div>
                    )
                ) : (
                     <div className="text-center py-20 text-gray-500">
                        <p>No active positions.</p>
                    </div>
                )}
            </main>

            <TradeDetailModal 
                isOpen={!!selectedTrade}
                onClose={() => setSelectedTrade(null)}
                trade={selectedTrade}
            />
        </div>
    );
};

export default HistoryScreen;