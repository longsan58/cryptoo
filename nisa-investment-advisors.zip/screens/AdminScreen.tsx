
import * as React from 'react';
import { Routes, Route, NavLink, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext.tsx';
import type { User, KycRequest, PendingDeposit, PendingWithdrawal, SystemSettings, Transaction, SecondContractTrade, UserStatus } from '../types.ts';
import { LayoutDashboard, Users, UserCheck, Banknote, LogOut, Loader, CheckCircle, XCircle, Home, Upload, Settings, ShieldQuestion, MoreVertical, Edit, PlusCircle, Trash2, Shield, ShieldOff, UserPlus, FileText, Search, ArrowUp, ArrowDown } from 'lucide-react';

// --- Reusable Components ---

const ImageModal = ({ isOpen, onClose, children }: { isOpen: boolean; onClose: () => void; children: React.ReactNode; }) => {
    if (!isOpen) return null;
    return (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center animate-fade-in-fast" onClick={onClose}>
            <div className="bg-white dark:bg-slate-900 rounded-lg p-6 max-w-4xl w-full m-4" onClick={(e) => e.stopPropagation()}>
                {children}
            </div>
        </div>
    );
};

const StatCard = ({ title, value, icon, color }: { title: string; value: string | number; icon: React.ReactNode, color: string }) => (
    <div className={`bg-white dark:bg-slate-900 p-6 rounded-xl shadow-md flex items-center space-x-4 border-l-4 ${color}`}>
        <div className="text-3xl">{icon}</div>
        <div>
            <p className="text-gray-500 dark:text-gray-400 text-sm font-medium">{title}</p>
            <p className="text-2xl font-bold text-slate-900 dark:text-white">{value}</p>
        </div>
    </div>
);

const AdminPasswordModal = ({ isOpen, onClose, onConfirm, isLoading }) => {
    const [password, setPassword] = React.useState('');
    if (!isOpen) return null;

    const handleSubmit = (e) => {
        e.preventDefault();
        onConfirm(password);
    }
    
    return (
        <div className="fixed inset-0 bg-black/70 z-[60] flex items-center justify-center" onClick={onClose}>
            <form onSubmit={handleSubmit} className="bg-white dark:bg-slate-900 p-6 rounded-lg shadow-xl w-full max-w-sm" onClick={e => e.stopPropagation()}>
                <h3 className="text-lg font-bold mb-4">Confirm Action</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">Please enter your admin password to proceed.</p>
                <input
                    type="password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="w-full bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-md px-3 py-2 focus:ring-purple-500 focus:border-purple-500"
                    placeholder="Admin Password"
                    required
                />
                <div className="flex justify-end gap-3 mt-6">
                    <button type="button" onClick={onClose} className="px-4 py-2 rounded-md text-sm font-medium bg-gray-200 dark:bg-slate-700 hover:bg-gray-300 dark:hover:bg-slate-600">Cancel</button>
                    <button type="submit" disabled={isLoading} className="px-4 py-2 rounded-md text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 disabled:opacity-50 flex items-center">
                        {isLoading && <Loader size={16} className="animate-spin mr-2" />}
                        Confirm
                    </button>
                </div>
            </form>
        </div>
    )
};

// --- Main Views ---
const DashboardView = () => {
    const { fetchAllUsers, fetchPendingKyc, fetchPendingDeposits, fetchPendingWithdrawals, getAllActiveContracts } = useAuth();
    const [stats, setStats] = React.useState({ users: 0, kyc: 0, deposits: 0, withdrawals: 0, contracts: 0 });
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        const fetchStats = async () => {
            setLoading(true);
            try {
                const [users, kyc, deposits, withdrawals, contracts] = await Promise.all([
                    fetchAllUsers(), fetchPendingKyc(), fetchPendingDeposits(), fetchPendingWithdrawals(), getAllActiveContracts()
                ]);
                setStats({ users: users.length, kyc: kyc.length, deposits: deposits.length, withdrawals: withdrawals.length, contracts: contracts.length });
            } catch (error) {
                console.error("Failed to fetch admin dashboard stats:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchStats();
    }, [fetchAllUsers, fetchPendingKyc, fetchPendingDeposits, fetchPendingWithdrawals, getAllActiveContracts]);
    
    if (loading) return <div className="flex justify-center items-center h-full"><Loader className="animate-spin" size={48} /></div>

    return (
        <div className="animate-fade-in">
            <h1 className="text-3xl font-bold mb-6 text-slate-900 dark:text-white">Admin Dashboard</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <StatCard title="Total Users" value={stats.users} icon={<Users />} color="border-purple-500" />
                <StatCard title="Pending KYC" value={stats.kyc} icon={<UserCheck />} color="border-yellow-500" />
                <StatCard title="Pending Deposits" value={stats.deposits} icon={<Banknote />} color="border-green-500" />
                <StatCard title="Pending Withdrawals" value={stats.withdrawals} icon={<Upload />} color="border-orange-500" />
                <StatCard title="Pending Contracts" value={stats.contracts} icon={<ShieldQuestion />} color="border-red-500" />
            </div>
        </div>
    );
};

const KycView = () => { /* Unchanged but kept for context */
    const { fetchPendingKyc, updateKycStatus, verifyAdminPassword } = useAuth();
    const [kycQueue, setKycQueue] = React.useState<KycRequest[]>([]);
    const [loading, setLoading] = React.useState(true);
    const [selectedRequest, setSelectedRequest] = React.useState<KycRequest | null>(null);
    const [isProcessing, setIsProcessing] = React.useState<string | null>(null);
    const [passwordModalOpen, setPasswordModalOpen] = React.useState(false);
    const [actionToConfirm, setActionToConfirm] = React.useState<((password: string) => Promise<void>) | null>(null);


    const loadQueue = React.useCallback(() => {
        setLoading(true);
        fetchPendingKyc().then(setKycQueue).finally(() => setLoading(false));
    }, [fetchPendingKyc]);
    
    React.useEffect(loadQueue, [loadQueue]);

    const handleAction = async (userId: string, status: 'verified' | 'rejected') => {
        setActionToConfirm(() => async (password) => {
            setIsProcessing(userId);
            try {
                await updateKycStatus(password, userId, status);
                setKycQueue(prev => prev.filter(req => req.user.uid !== userId));
                setSelectedRequest(null);
            } catch (error) {
                console.error(`Failed to ${status} KYC for ${userId}:`, error);
                alert(`Error: ${error.message}`);
            } finally {
                setIsProcessing(null);
            }
        });
        setPasswordModalOpen(true);
    };

    const onPasswordConfirm = async (password: string) => {
        if (actionToConfirm) {
            await actionToConfirm(password);
        }
        setPasswordModalOpen(false);
        setActionToConfirm(null);
    }
    
    if (loading) return <div className="flex justify-center items-center h-full"><Loader className="animate-spin" size={48} /></div>;

    return (
        <div className="animate-fade-in">
            <h1 className="text-3xl font-bold mb-6 text-slate-900 dark:text-white">KYC Approval Queue</h1>
             <AdminPasswordModal isOpen={passwordModalOpen} onClose={() => setPasswordModalOpen(false)} onConfirm={onPasswordConfirm} isLoading={!!isProcessing} />
            {kycQueue.length === 0 ? (
                <p className="text-center text-gray-500 dark:text-gray-400 py-10">No pending KYC requests.</p>
            ) : (
                <div className="space-y-4">
                    {kycQueue.map(req => (
                        <div key={req.user.uid} className="bg-white dark:bg-slate-900 p-4 rounded-lg shadow-md flex justify-between items-center">
                            <div>
                                <p className="font-bold">{req.user.fullName || req.user.name}</p>
                                <p className="text-sm text-gray-500 dark:text-gray-400">{req.user.email}</p>
                            </div>
                            <button onClick={() => setSelectedRequest(req)} className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition">
                                Review
                            </button>
                        </div>
                    ))}
                </div>
            )}
            {selectedRequest && (
                 <ImageModal isOpen={!!selectedRequest} onClose={() => setSelectedRequest(null)}>
                     <div className="flex justify-between items-center mb-4">
                        <h3 className="text-xl font-bold text-slate-900 dark:text-white">{`KYC for ${selectedRequest.user.name}`}</h3>
                        <button onClick={() => setSelectedRequest(null)} className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-slate-700">
                            <XCircle size={24} />
                        </button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4 max-h-[70vh] overflow-y-auto">
                         <img src={selectedRequest.kycImages.idFront} alt="ID Front" className="w-full object-contain rounded-md border dark:border-slate-700" />
                         <img src={selectedRequest.kycImages.idBack} alt="ID Back" className="w-full object-contain rounded-md border dark:border-slate-700" />
                    </div>
                     <div className="flex justify-end space-x-3 mt-4">
                        <button disabled={!!isProcessing} onClick={() => handleAction(selectedRequest.user.uid, 'rejected')} className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition flex items-center disabled:opacity-50">
                            {isProcessing === selectedRequest.user.uid ? <Loader size={20} className="animate-spin mr-2" /> : <XCircle size={20} className="mr-2" />} Reject
                        </button>
                         <button disabled={!!isProcessing} onClick={() => handleAction(selectedRequest.user.uid, 'verified')} className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition flex items-center disabled:opacity-50">
                            {isProcessing === selectedRequest.user.uid ? <Loader size={20} className="animate-spin mr-2" /> : <CheckCircle size={20} className="mr-2" />} Approve
                        </button>
                    </div>
                </ImageModal>
            )}
        </div>
    );
};

const DepositsView = () => {
    const { fetchPendingDeposits, updateDepositStatus } = useAuth();
    const [depositQueue, setDepositQueue] = React.useState<PendingDeposit[]>([]);
    const [loading, setLoading] = React.useState(true);
    const [selectedDeposit, setSelectedDeposit] = React.useState<PendingDeposit | null>(null);
    const [isProcessing, setIsProcessing] = React.useState<string | null>(null);
    const [passwordModalOpen, setPasswordModalOpen] = React.useState(false);
    const [actionToConfirm, setActionToConfirm] = React.useState<((password: string) => Promise<void>) | null>(null);
    
    const [searchTerm, setSearchTerm] = React.useState('');
    const [sortConfig, setSortConfig] = React.useState<{ key: 'userName' | 'amount' | 'date'; direction: 'ascending' | 'descending' }>({ key: 'date', direction: 'descending' });

    const loadQueue = React.useCallback(() => {
        setLoading(true);
        fetchPendingDeposits().then(setDepositQueue).finally(() => setLoading(false));
    }, [fetchPendingDeposits]);
    
    React.useEffect(loadQueue, [loadQueue]);

    const filteredAndSortedDeposits = React.useMemo(() => {
        let sortableItems = [...depositQueue];
        if (searchTerm) {
            sortableItems = sortableItems.filter(d =>
                d.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                d.userEmail.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }
        sortableItems.sort((a, b) => {
            let aValue, bValue;
            if (sortConfig.key === 'amount') {
                aValue = a.transaction.amount;
                bValue = b.transaction.amount;
            } else if (sortConfig.key === 'date') {
                aValue = new Date(a.transaction.date).getTime();
                bValue = new Date(b.transaction.date).getTime();
            } else { // userName
                aValue = a.userName;
                bValue = b.userName;
            }

            if (aValue < bValue) return sortConfig.direction === 'ascending' ? -1 : 1;
            if (aValue > bValue) return sortConfig.direction === 'ascending' ? 1 : -1;
            return 0;
        });
        return sortableItems;
    }, [depositQueue, searchTerm, sortConfig]);

    const requestSort = (key: 'userName' | 'amount' | 'date') => {
        let direction: 'ascending' | 'descending' = 'ascending';
        if (sortConfig.key === key && sortConfig.direction === 'ascending') {
            direction = 'descending';
        }
        setSortConfig({ key, direction });
    };

    const handleAction = async (deposit: PendingDeposit, status: 'Completed' | 'Failed') => {
        setActionToConfirm(() => async (password) => {
            setIsProcessing(deposit.transaction.id);
            try {
                await updateDepositStatus(password, deposit.userId, deposit.transaction.id, status);
                setDepositQueue(prev => prev.filter(d => d.transaction.id !== deposit.transaction.id));
                setSelectedDeposit(null);
            } catch (error) {
                console.error(`Failed to update deposit ${deposit.transaction.id}:`, error);
                alert(`Error: ${error.message}`);
            } finally {
                setIsProcessing(null);
            }
        });
        setPasswordModalOpen(true);
    };

    const onPasswordConfirm = async (password: string) => {
        if (actionToConfirm) {
            await actionToConfirm(password);
        }
        setPasswordModalOpen(false);
        setActionToConfirm(null);
    }
    
    const formatDate = (isoString: string) => new Date(isoString).toLocaleString();

    if (loading) return <div className="flex justify-center items-center h-full"><Loader className="animate-spin" size={48} /></div>;

    const SortableHeader = ({ label, sortKey }: { label: string; sortKey: 'userName' | 'amount' | 'date'}) => {
        const isSorted = sortConfig.key === sortKey;
        return (
            <th className="p-4 text-sm font-semibold text-left">
                <button onClick={() => requestSort(sortKey)} className="flex items-center gap-2 hover:text-purple-400">
                    {label}
                    {isSorted && (sortConfig.direction === 'ascending' ? <ArrowUp size={14} /> : <ArrowDown size={14} />)}
                </button>
            </th>
        );
    };

    return (
        <div className="animate-fade-in">
            <h1 className="text-3xl font-bold mb-6 text-slate-900 dark:text-white">Deposit Approval Queue</h1>
             <AdminPasswordModal isOpen={passwordModalOpen} onClose={() => setPasswordModalOpen(false)} onConfirm={onPasswordConfirm} isLoading={!!isProcessing} />
             
             <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500" size={20} />
                <input
                    type="text"
                    placeholder="Filter by user name or email..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-white dark:bg-slate-900 border border-gray-300 dark:border-slate-700 rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
            </div>

             {filteredAndSortedDeposits.length === 0 ? (
                <p className="text-center text-gray-500 dark:text-gray-400 py-10">No pending deposit requests found.</p>
            ) : (
                <div className="bg-white dark:bg-slate-900 rounded-lg shadow-md overflow-x-auto">
                    <table className="w-full">
                        <thead className="bg-gray-50 dark:bg-slate-800">
                            <tr>
                                <SortableHeader label="User" sortKey="userName" />
                                <SortableHeader label="Amount" sortKey="amount" />
                                <th className="p-4 text-sm font-semibold text-left">Network</th>
                                <SortableHeader label="Date" sortKey="date" />
                                <th className="p-4 text-sm font-semibold text-left">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200 dark:divide-slate-800">
                            {filteredAndSortedDeposits.map(d => (
                                <tr key={d.transaction.id} className="hover:bg-gray-50 dark:hover:bg-slate-800/50">
                                    <td className="p-4">
                                        <p className="font-bold">{d.userName}</p>
                                        <p className="text-sm text-gray-500 dark:text-gray-400">{d.userEmail}</p>
                                    </td>
                                    <td className="p-4">
                                        <p className="font-semibold text-green-500">+{d.transaction.amount.toLocaleString()} {d.transaction.asset}</p>
                                    </td>
                                    <td className="p-4 text-sm text-gray-500 dark:text-gray-400">{d.transaction.network}</td>
                                    <td className="p-4 text-sm text-gray-500 dark:text-gray-400">{formatDate(d.transaction.date)}</td>
                                    <td className="p-4">
                                        <button onClick={() => setSelectedDeposit(d)} className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition text-sm font-medium">
                                            Review
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
             {selectedDeposit && (
                 <ImageModal isOpen={!!selectedDeposit} onClose={() => setSelectedDeposit(null)}>
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-xl font-bold text-slate-900 dark:text-white">{`Deposit Proof for ${selectedDeposit.userName}`}</h3>
                        <button onClick={() => setSelectedDeposit(null)} className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-slate-800"><XCircle size={24} /></button>
                    </div>
                    <div className="mb-4">
                         <img src={selectedDeposit.transaction.transactionProof} alt="Transaction Proof" className="max-h-[60vh] mx-auto w-auto object-contain rounded-md border dark:border-slate-700" />
                    </div>
                     <div className="flex justify-end space-x-3 mt-4">
                        <button disabled={!!isProcessing} onClick={() => handleAction(selectedDeposit, 'Failed')} className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition flex items-center disabled:opacity-50">
                            {isProcessing === selectedDeposit.transaction.id ? <Loader size={20} className="animate-spin mr-2" /> : <XCircle size={20} className="mr-2" />} Reject
                        </button>
                         <button disabled={!!isProcessing} onClick={() => handleAction(selectedDeposit, 'Completed')} className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition flex items-center disabled:opacity-50">
                            {isProcessing === selectedDeposit.transaction.id ? <Loader size={20} className="animate-spin mr-2" /> : <CheckCircle size={20} className="mr-2" />} Approve
                        </button>
                    </div>
                </ImageModal>
            )}
        </div>
    );
};

const WithdrawalsView = () => {
    const { fetchPendingWithdrawals, updateWithdrawalStatus } = useAuth();
    const [withdrawalQueue, setWithdrawalQueue] = React.useState<PendingWithdrawal[]>([]);
    const [loading, setLoading] = React.useState(true);
    const [isProcessing, setIsProcessing] = React.useState<string | null>(null);
    const [passwordModalOpen, setPasswordModalOpen] = React.useState(false);
    const [actionToConfirm, setActionToConfirm] = React.useState<((password: string) => Promise<void>) | null>(null);

    const loadQueue = React.useCallback(() => {
        setLoading(true);
        fetchPendingWithdrawals().then(setWithdrawalQueue).finally(() => setLoading(false));
    }, [fetchPendingWithdrawals]);

    React.useEffect(loadQueue, [loadQueue]);

    const handleAction = (withdrawal: PendingWithdrawal, status: 'Completed' | 'Failed') => {
        setActionToConfirm(() => async (password) => {
            setIsProcessing(withdrawal.transaction.id);
            try {
                await updateWithdrawalStatus(password, withdrawal.userId, withdrawal.transaction.id, status);
                setWithdrawalQueue(prev => prev.filter(w => w.transaction.id !== withdrawal.transaction.id));
            } catch (error) {
                alert(`Error: ${error.message}`);
            } finally {
                setIsProcessing(null);
            }
        });
        setPasswordModalOpen(true);
    };
    
     const onPasswordConfirm = async (password: string) => {
        if (actionToConfirm) await actionToConfirm(password);
        setPasswordModalOpen(false);
        setActionToConfirm(null);
    }

    if (loading) return <div className="flex justify-center items-center h-full"><Loader className="animate-spin" size={48} /></div>;

    return (
        <div className="animate-fade-in">
            <h1 className="text-3xl font-bold mb-6">Withdrawal Approval Queue</h1>
             <AdminPasswordModal isOpen={passwordModalOpen} onClose={() => setPasswordModalOpen(false)} onConfirm={onPasswordConfirm} isLoading={!!isProcessing} />
            {withdrawalQueue.length === 0 ? (
                <p className="text-center text-gray-500 py-10">No pending withdrawal requests.</p>
            ) : (
                <div className="bg-white dark:bg-slate-900 rounded-lg shadow-md overflow-hidden">
                    <table className="w-full text-left">
                        <thead className="bg-gray-50 dark:bg-slate-800">
                            <tr>
                                <th className="p-4 text-sm font-semibold">User</th>
                                <th className="p-4 text-sm font-semibold">Amount</th>
                                <th className="p-4 text-sm font-semibold">Address</th>
                                <th className="p-4 text-sm font-semibold">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {withdrawalQueue.map(w => (
                                <tr key={w.transaction.id} className="border-b dark:border-slate-800">
                                    <td className="p-4">
                                        <p className="font-bold">{w.userName}</p>
                                        <p className="text-xs text-gray-500">{w.userEmail}</p>
                                    </td>
                                    <td className="p-4 text-red-500 font-semibold">-{w.transaction.amount.toLocaleString()} {w.transaction.asset}</td>
                                    <td className="p-4 font-mono text-xs">{w.transaction.address}</td>
                                    <td className="p-4">
                                        <div className="flex gap-2">
                                            <button onClick={() => handleAction(w, 'Completed')} disabled={!!isProcessing} className="p-2 bg-green-500 text-white rounded hover:bg-green-600 disabled:opacity-50"><CheckCircle size={16}/></button>
                                            <button onClick={() => handleAction(w, 'Failed')} disabled={!!isProcessing} className="p-2 bg-red-500 text-white rounded hover:bg-red-600 disabled:opacity-50"><XCircle size={16}/></button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
};

const ContractsView = () => {
    const { getAllActiveContracts, adminResolveContract } = useAuth();
    const [contracts, setContracts] = React.useState<SecondContractTrade[]>([]);
    const [loading, setLoading] = React.useState(true);
    const [isProcessing, setIsProcessing] = React.useState<string | null>(null);
    const [passwordModalOpen, setPasswordModalOpen] = React.useState(false);
    const [actionToConfirm, setActionToConfirm] = React.useState<((password: string) => Promise<void>) | null>(null);

    const loadContracts = React.useCallback(() => {
        setLoading(true);
        getAllActiveContracts().then(setContracts).finally(() => setLoading(false));
    }, [getAllActiveContracts]);

    React.useEffect(loadContracts, [loadContracts]);

    const handleAction = (tradeId: string, resolution: 'win' | 'loss') => {
        setActionToConfirm(() => async (password) => {
            setIsProcessing(tradeId);
            try {
                await adminResolveContract(password, tradeId, resolution);
                setContracts(prev => prev.filter(c => c.id !== tradeId));
            } catch (error) {
                alert(`Error: ${error.message}`);
            } finally {
                setIsProcessing(null);
            }
        });
        setPasswordModalOpen(true);
    };
    
     const onPasswordConfirm = async (password: string) => {
        if (actionToConfirm) await actionToConfirm(password);
        setPasswordModalOpen(false);
        setActionToConfirm(null);
    }
    
    if (loading) return <div className="flex justify-center items-center h-full"><Loader className="animate-spin" size={48} /></div>;

    return (
        <div className="animate-fade-in">
            <h1 className="text-3xl font-bold mb-6">Pending Contract Settlements</h1>
            <AdminPasswordModal isOpen={passwordModalOpen} onClose={() => setPasswordModalOpen(false)} onConfirm={onPasswordConfirm} isLoading={!!isProcessing} />
            {contracts.length === 0 ? (
                <p className="text-center text-gray-500 py-10">No contracts awaiting settlement.</p>
            ) : (
                 <div className="bg-white dark:bg-slate-900 rounded-lg shadow-md overflow-hidden">
                    <table className="w-full text-left">
                        <thead className="bg-gray-50 dark:bg-slate-800">
                            <tr>
                                <th className="p-4 text-sm font-semibold">User</th>
                                <th className="p-4 text-sm font-semibold">Amount</th>
                                <th className="p-4 text-sm font-semibold">Type</th>
                                <th className="p-4 text-sm font-semibold">Entry Price</th>
                                <th className="p-4 text-sm font-semibold">Close Price</th>
                                <th className="p-4 text-sm font-semibold">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                           {contracts.map(c => (
                               <tr key={c.id} className="border-b dark:border-slate-800">
                                   <td className="p-4 font-bold">{c.userName || c.userId}</td>
                                   <td className="p-4 font-semibold">${c.amount.toLocaleString()}</td>
                                   <td className={`p-4 font-bold ${c.type === 'buy' ? 'text-green-500' : 'text-red-500'}`}>{c.type.toUpperCase()}</td>
                                   <td className="p-4">{c.entryPrice.toFixed(2)}</td>
                                   <td className="p-4">{c.closePrice?.toFixed(2)}</td>
                                   <td className="p-4">
                                       <div className="flex gap-2">
                                           <button onClick={() => handleAction(c.id, 'win')} disabled={!!isProcessing} className="p-2 bg-green-500 text-white rounded hover:bg-green-600 disabled:opacity-50"><CheckCircle size={16}/></button>
                                           <button onClick={() => handleAction(c.id, 'loss')} disabled={!!isProcessing} className="p-2 bg-red-500 text-white rounded hover:bg-red-600 disabled:opacity-50"><XCircle size={16}/></button>
                                       </div>
                                   </td>
                               </tr>
                           ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
};

const SettingsView = () => {
    const { getSystemSettings, updateSystemSettings } = useAuth();
    const [settings, setSettings] = React.useState<SystemSettings | null>(null);
    const [loading, setLoading] = React.useState(true);
    const [isSaving, setIsSaving] = React.useState(false);
    const [passwordModalOpen, setPasswordModalOpen] = React.useState(false);
    const [error, setError] = React.useState('');
    const [success, setSuccess] = React.useState('');

    React.useEffect(() => {
        getSystemSettings()
            .then(setSettings)
            .catch(err => setError("Failed to load settings."))
            .finally(() => setLoading(false));
    }, [getSystemSettings]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (!settings) return;
        const { name, value } = e.target;
        setSettings({ ...settings, [name]: value });
    };

    const handleActionItemChange = (id: string, field: string, value: string | boolean) => {
        if (!settings) return;
        setSettings({
            ...settings,
            homepageActionItems: settings.homepageActionItems.map(item =>
                item.id === id ? { ...item, [field]: value } : item
            ),
        });
    };

    const handleSave = () => {
        setError('');
        setSuccess('');
        setPasswordModalOpen(true);
    };

    const onPasswordConfirm = async (password: string) => {
        if (!settings) return;
        setIsSaving(true);
        try {
            await updateSystemSettings(password, settings);
            setSuccess("Settings updated successfully!");
        } catch (err) {
            setError(err instanceof Error ? err.message : "Failed to update settings.");
        } finally {
            setIsSaving(false);
            setPasswordModalOpen(false);
        }
    };

    if (loading) return <div className="flex justify-center items-center h-full"><Loader className="animate-spin" size={48} /></div>;
    if (!settings) return <div className="text-center text-red-500">Could not load system settings.</div>;

    return (
        <div className="animate-fade-in">
            <h1 className="text-3xl font-bold mb-6 text-slate-900 dark:text-white">System Settings</h1>
             <AdminPasswordModal isOpen={passwordModalOpen} onClose={() => setPasswordModalOpen(false)} onConfirm={onPasswordConfirm} isLoading={isSaving} />

            <div className="bg-white dark:bg-slate-900 p-6 rounded-lg shadow-md space-y-8 max-w-4xl mx-auto">
                {/* Deposit Addresses */}
                <div>
                    <h2 className="text-xl font-bold mb-4">Deposit Addresses</h2>
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="depositAddressTrc20" className="block text-sm font-medium text-gray-500 dark:text-gray-400">TRC20 (USDT)</label>
                            <input
                                type="text"
                                id="depositAddressTrc20"
                                name="depositAddressTrc20"
                                value={settings.depositAddressTrc20}
                                onChange={handleInputChange}
                                className="mt-1 w-full bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-md px-3 py-2 focus:ring-purple-500 focus:border-purple-500"
                            />
                        </div>
                         <div>
                            <label htmlFor="depositAddressErc20" className="block text-sm font-medium text-gray-500 dark:text-gray-400">ERC20 (USDT)</label>
                            <input
                                type="text"
                                id="depositAddressErc20"
                                name="depositAddressErc20"
                                value={settings.depositAddressErc20}
                                onChange={handleInputChange}
                                className="mt-1 w-full bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-md px-3 py-2 focus:ring-purple-500 focus:border-purple-500"
                            />
                        </div>
                         <div>
                            <label htmlFor="depositAddressBtc" className="block text-sm font-medium text-gray-500 dark:text-gray-400">Bitcoin (BTC)</label>
                            <input
                                type="text"
                                id="depositAddressBtc"
                                name="depositAddressBtc"
                                value={settings.depositAddressBtc}
                                onChange={handleInputChange}
                                className="mt-1 w-full bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-md px-3 py-2 focus:ring-purple-500 focus:border-purple-500"
                            />
                        </div>
                    </div>
                </div>

                {/* Homepage Action Items */}
                <div>
                     <h2 className="text-xl font-bold mb-4">Homepage Actions</h2>
                     <div className="space-y-6">
                        {settings.homepageActionItems.sort((a,b) => a.order - b.order).map(item => (
                            <div key={item.id} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end p-4 border dark:border-slate-700 rounded-lg">
                                <div className="md:col-span-2">
                                    <label htmlFor={`label-${item.id}`} className="block text-sm font-medium text-gray-500 dark:text-gray-400">Label</label>
                                    <input
                                        type="text"
                                        id={`label-${item.id}`}
                                        value={item.label}
                                        onChange={(e) => handleActionItemChange(item.id, 'label', e.target.value)}
                                        className="mt-1 w-full bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-md px-3 py-2 focus:ring-purple-500 focus:border-purple-500"
                                    />
                                </div>
                                 <div>
                                    <label htmlFor={`icon-${item.id}`} className="block text-sm font-medium text-gray-500 dark:text-gray-400">Icon</label>
                                    <input
                                        type="text"
                                        id={`icon-${item.id}`}
                                        value={item.icon}
                                        onChange={(e) => handleActionItemChange(item.id, 'icon', e.target.value)}
                                        className="mt-1 w-full bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-md px-3 py-2 focus:ring-purple-500 focus:border-purple-500"
                                    />
                                </div>
                                <div className="flex items-center space-x-2 justify-self-start self-center pt-6">
                                    <input
                                        type="checkbox"
                                        id={`enabled-${item.id}`}
                                        checked={item.enabled}
                                        onChange={(e) => handleActionItemChange(item.id, 'enabled', e.target.checked)}
                                        className="h-5 w-5 rounded text-purple-600 focus:ring-purple-500 border-gray-300 dark:border-slate-600 bg-gray-100 dark:bg-slate-700"
                                    />
                                    <label htmlFor={`enabled-${item.id}`} className="font-medium text-gray-700 dark:text-gray-300">Enabled</label>
                                </div>
                            </div>
                        ))}
                     </div>
                </div>

                {/* Save button and messages */}
                <div>
                     {error && <p className="mb-4 text-sm text-center text-red-500 dark:text-red-400 p-3 bg-red-100 dark:bg-red-900/50 rounded-lg">{error}</p>}
                    {success && <p className="mb-4 text-sm text-center text-green-500 dark:text-green-400 p-3 bg-green-100 dark:bg-green-900/50 rounded-lg">{success}</p>}
                    <button
                        onClick={handleSave}
                        disabled={isSaving}
                        className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:bg-purple-400"
                    >
                         {isSaving ? <Loader className="animate-spin" /> : 'Save Settings'}
                    </button>
                </div>
            </div>
        </div>
    );
};


// --- Main Admin Layout ---

const AdminSidebar = () => {
    const { logout } = useAuth();
    const navigate = useNavigate();
    const NavItem = ({ to, icon, label }: { to:string, icon:React.ReactNode, label:string }) => {
        const location = useLocation();
        const isActive = location.pathname === to || (to === '/admin' && location.pathname === '/admin/');
        
        const baseClasses = "flex items-center space-x-3 px-3 py-3 rounded-lg transition-colors duration-200";
        const inactiveClasses = "text-gray-600 dark:text-gray-300 hover:bg-purple-100 hover:text-purple-700 dark:hover:bg-slate-800";
        const activeClasses = "bg-purple-600 text-white font-semibold shadow-lg";
        return (
             <NavLink to={to} className={`${baseClasses} ${isActive ? activeClasses : inactiveClasses}`}>
                {icon}
                <span>{label}</span>
            </NavLink>
        );
    }

    return (
        <aside className="w-64 bg-white dark:bg-slate-900 p-4 flex flex-col border-r border-gray-200 dark:border-slate-800/50">
            <div className="flex items-center space-x-2 mb-10">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-purple-600 to-indigo-500"></div>
                <h2 className="text-xl font-bold">NISA</h2>
            </div>
            <nav className="flex-1 space-y-2">
                <NavItem to="/admin" icon={<LayoutDashboard size={20} />} label="Dashboard" />
                <NavItem to="/admin/users" icon={<Users size={20} />} label="Users" />
                <NavItem to="/admin/kyc" icon={<UserCheck size={20} />} label="KYC Queue" />
                <NavItem to="/admin/deposits" icon={<Banknote size={20} />} label="Deposits Queue" />
                <NavItem to="/admin/withdrawals" icon={<Upload size={20} />} label="Withdrawals" />
                <NavItem to="/admin/contracts" icon={<ShieldQuestion size={20} />} label="Contracts" />
                <NavItem to="/admin/settings" icon={<Settings size={20} />} label="Settings" />
            </nav>
            <div className="mt-auto space-y-2">
                 <button onClick={() => navigate('/')} className="w-full flex items-center space-x-3 px-3 py-3 rounded-lg transition-colors duration-200 text-gray-600 dark:text-gray-300 hover:bg-purple-100 hover:text-purple-700 dark:hover:bg-slate-800">
                    <Home size={20} />
                    <span>Back to App</span>
                </button>
                 <button onClick={logout} className="w-full flex items-center space-x-3 px-3 py-3 rounded-lg transition-colors duration-200 text-red-500 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-900/50">
                    <LogOut size={20} />
                    <span>Log Out</span>
                </button>
            </div>
        </aside>
    );
};

const AdminScreen = () => {
    return (
        <div className="flex min-h-screen bg-gray-100 dark:bg-slate-950 text-slate-900 dark:text-white">
            <AdminSidebar />
            <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
                <Routes>
                    <Route index element={<DashboardView />} />
                    <Route path="users" element={<UsersView />} />
                    <Route path="kyc" element={<KycView />} />
                    <Route path="deposits" element={<DepositsView />} />
                    <Route path="withdrawals" element={<WithdrawalsView />} />
                    <Route path="contracts" element={<ContractsView />} />
                    <Route path="settings" element={<SettingsView />} />
                </Routes>
            </main>
        </div>
    );
};

const UsersView = () => {
    const { fetchAllUsers, adminCreateUser, updateUserBalance, adminUpdateUser, addManualTransaction } = useAuth();
    const [users, setUsers] = React.useState<User[]>([]);
    const [loading, setLoading] = React.useState(true);
    const [isModalOpen, setModalOpen] = React.useState(false);
    const [modalMode, setModalMode] = React.useState<'create' | 'balance' | 'transaction' | null>(null);
    const [selectedUser, setSelectedUser] = React.useState<User | null>(null);
    const [formData, setFormData] = React.useState({});
    const [isProcessing, setIsProcessing] = React.useState(false);
    const [passwordModalOpen, setPasswordModalOpen] = React.useState(false);
    const [actionToConfirm, setActionToConfirm] = React.useState<((password: string) => Promise<void>) | null>(null);
    
    const loadUsers = React.useCallback(() => {
        setLoading(true);
        fetchAllUsers().then(setUsers).finally(() => setLoading(false));
    }, [fetchAllUsers]);

    React.useEffect(loadUsers, [loadUsers]);
    
    const openModal = (mode: 'create' | 'balance' | 'transaction', user: User | null = null) => {
        setModalMode(mode);
        setSelectedUser(user);
        setFormData(mode === 'balance' ? { balance: user?.portfolio.balance || 0 } : {});
        setModalOpen(true);
    };

    const closeModal = () => {
        setModalOpen(false);
        setModalMode(null);
        setSelectedUser(null);
        setFormData({});
        setIsProcessing(false);
    };
    
    const onPasswordConfirm = async (password: string) => {
        if (actionToConfirm) {
            setIsProcessing(true);
            try {
                await actionToConfirm(password);
                loadUsers();
            } catch (error) {
                alert(`Error: ${error.message}`);
            } finally {
                setIsProcessing(false);
                setActionToConfirm(null);
                setPasswordModalOpen(false);
                closeModal();
            }
        }
    };
    
    const handleFormSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setActionToConfirm(() => async (password: string) => {
            switch(modalMode) {
                case 'balance':
                    await updateUserBalance(password, selectedUser!.uid, formData['balance']);
                    break;
                case 'transaction':
                     await addManualTransaction(password, { 
                        userEmail: selectedUser!.email,
                        ...formData
                     } as any);
                    break;
            }
        });
        
        if (modalMode === 'create') {
            setIsProcessing(true);
            try {
                await adminCreateUser(formData as any);
                loadUsers();
            } catch(e) { alert(`Error: ${e.message}`) }
            finally {
                setIsProcessing(false);
                closeModal();
            }
        } else {
             setPasswordModalOpen(true);
        }
    };

    const handleToggleAdmin = (user: User) => {
        setActionToConfirm(() => async (password: string) => {
            await adminUpdateUser(password, user.uid, { isAdmin: !user.isAdmin });
        });
        setPasswordModalOpen(true);
    };
    
    const handleToggleSuspend = (user: User) => {
        setActionToConfirm(() => async (password: string) => {
            const newStatus: UserStatus = user.status === 'active' ? 'suspended' : 'active';
            await adminUpdateUser(password, user.uid, { status: newStatus });
        });
        setPasswordModalOpen(true);
    };
    
    const renderModalContent = () => {
        if (!modalMode) return null;
        switch(modalMode) {
            case 'create':
                return <>
                    <h3 className="text-lg font-bold mb-4">Create New User</h3>
                    <div className="space-y-4">
                        <input type="text" placeholder="Name" onChange={e => setFormData({...formData, name: e.target.value})} className="w-full bg-gray-100 dark:bg-slate-800 p-2 rounded-md" />
                        <input type="email" placeholder="Email" onChange={e => setFormData({...formData, email: e.target.value})} className="w-full bg-gray-100 dark:bg-slate-800 p-2 rounded-md" />
                        <input type="password" placeholder="Password (optional)" onChange={e => setFormData({...formData, password: e.target.value})} className="w-full bg-gray-100 dark:bg-slate-800 p-2 rounded-md" />
                    </div>
                </>;
            case 'balance':
                return <>
                    <h3 className="text-lg font-bold mb-4">Edit Balance for {selectedUser?.name}</h3>
                    <input type="number" value={formData['balance'] || ''} onChange={e => setFormData({balance: Number(e.target.value)})} className="w-full bg-gray-100 dark:bg-slate-800 p-2 rounded-md" />
                </>;
            case 'transaction':
                 return <>
                    <h3 className="text-lg font-bold mb-4">Add Manual Transaction for {selectedUser?.name}</h3>
                    <div className="space-y-4">
                        <select onChange={e => setFormData({...formData, type: e.target.value})} className="w-full bg-gray-100 dark:bg-slate-800 p-2 rounded-md">
                            <option value="">Select Type</option>
                            <option value="Deposit">Deposit</option>
                            <option value="Withdrawal">Withdrawal</option>
                        </select>
                         <input type="text" placeholder="Asset (e.g., USDT)" onChange={e => setFormData({...formData, asset: e.target.value})} className="w-full bg-gray-100 dark:bg-slate-800 p-2 rounded-md" />
                        <input type="number" placeholder="Amount" onChange={e => setFormData({...formData, amount: Number(e.target.value)})} className="w-full bg-gray-100 dark:bg-slate-800 p-2 rounded-md" />
                    </div>
                </>;
        }
    };
    
    if (loading) return <div className="flex justify-center items-center h-full"><Loader className="animate-spin" size={48} /></div>;

    return (
         <div className="animate-fade-in">
             <AdminPasswordModal isOpen={passwordModalOpen} onClose={() => setPasswordModalOpen(false)} onConfirm={onPasswordConfirm} isLoading={isProcessing} />
             {isModalOpen && (
                 <div className="fixed inset-0 bg-black/70 z-[60] flex items-center justify-center" onClick={closeModal}>
                    <form onSubmit={handleFormSubmit} className="bg-white dark:bg-slate-900 p-6 rounded-lg shadow-xl w-full max-w-sm" onClick={e => e.stopPropagation()}>
                       {renderModalContent()}
                        <div className="flex justify-end gap-3 mt-6">
                            <button type="button" onClick={closeModal} className="px-4 py-2 rounded-md text-sm font-medium bg-gray-200 dark:bg-slate-700 hover:bg-gray-300 dark:hover:bg-slate-600">Cancel</button>
                            <button type="submit" disabled={isProcessing} className="px-4 py-2 rounded-md text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 disabled:opacity-50 flex items-center">
                                {isProcessing && <Loader size={16} className="animate-spin mr-2" />}
                                Confirm
                            </button>
                        </div>
                    </form>
                </div>
             )}
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold text-slate-900 dark:text-white">User Management</h1>
                <button onClick={() => openModal('create')} className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition">
                    <UserPlus size={18} />
                    Create User
                </button>
            </div>
            <div className="bg-white dark:bg-slate-900 rounded-lg shadow-md overflow-x-auto">
                <table className="w-full text-left">
                    <thead className="bg-gray-50 dark:bg-slate-800">
                        <tr>
                            <th className="p-4 text-sm font-semibold">User</th>
                            <th className="p-4 text-sm font-semibold">Balance</th>
                            <th className="p-4 text-sm font-semibold">KYC</th>
                            <th className="p-4 text-sm font-semibold">Status</th>
                            <th className="p-4 text-sm font-semibold">Role</th>
                            <th className="p-4 text-sm font-semibold">Referral Code</th>
                            <th className="p-4 text-sm font-semibold">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.map(user => (
                            <tr key={user.uid} className="border-b border-gray-200 dark:border-slate-800">
                                <td className="p-4">
                                    <p className="font-bold">{user.name}</p>
                                    <p className="text-xs text-gray-500">{user.email}</p>
                                </td>
                                <td className="p-4 font-mono">${user.portfolio.balance.toLocaleString('en-US', {minimumFractionDigits: 2})}</td>
                                <td className="p-4"><span className={`px-2 py-1 text-xs font-semibold rounded-full ${user.kycStatus === 'verified' ? 'bg-green-100 text-green-800 dark:bg-green-800/50 dark:text-green-300' : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-800/50 dark:text-yellow-300'}`}>{user.kycStatus}</span></td>
                                <td className="p-4"><span className={`px-2 py-1 text-xs font-semibold rounded-full ${user.status === 'active' ? 'bg-green-100 text-green-800 dark:bg-green-800/50 dark:text-green-300' : 'bg-red-100 text-red-800 dark:bg-red-800/50 dark:text-red-300'}`}>{user.status}</span></td>
                                <td className="p-4"><span className={`px-2 py-1 text-xs font-semibold rounded-full ${user.isAdmin ? 'bg-purple-100 text-purple-800 dark:bg-purple-800/50 dark:text-purple-300' : 'bg-gray-100 text-gray-800 dark:bg-gray-600 dark:text-gray-300'}`}>{user.isAdmin ? 'Admin' : 'User'}</span></td>
                                <td className="p-4 font-mono text-xs">{user.referralCode}</td>
                                <td className="p-4">
                                    <div className="relative group">
                                        <button className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-slate-800">
                                            <MoreVertical size={16} />
                                        </button>
                                        <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-800 rounded-md shadow-lg z-10 hidden group-hover:block border dark:border-slate-700">
                                            <button onClick={() => openModal('balance', user)} className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700"><Edit size={14} className="mr-2"/>Edit Balance</button>
                                            <button onClick={() => openModal('transaction', user)} className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700"><PlusCircle size={14} className="mr-2"/>Add Transaction</button>
                                            <button onClick={() => handleToggleSuspend(user)} className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700"><Trash2 size={14} className="mr-2"/>{user.status === 'active' ? 'Suspend' : 'Unsuspend'}</button>
                                            <button onClick={() => handleToggleAdmin(user)} className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700">{user.isAdmin ? <ShieldOff size={14} className="mr-2"/> : <Shield size={14} className="mr-2"/>}{user.isAdmin ? 'Revoke Admin' : 'Make Admin'}</button>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

export default AdminScreen;