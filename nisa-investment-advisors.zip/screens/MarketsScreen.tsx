
import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, RefreshCw, LayoutGrid } from 'lucide-react';
import type { CryptoCoin, SortKey } from '../types.ts';

const MarketsScreen = () => {
    const [coins, setCoins] = React.useState<CryptoCoin[]>([]);
    const [loading, setLoading] = React.useState<boolean>(true);
    const [error, setError] = React.useState<string | null>(null);
    const [searchTerm, setSearchTerm] = React.useState<string>('');
    const [currency, setCurrency] = React.useState<'usd' | 'brl'>('usd');
    const [sortKey, setSortKey] = React.useState<SortKey>('market_cap');
    const [sortOrder, setSortOrder] = React.useState<'asc' | 'desc'>('desc');
    const [isRefreshing, setIsRefreshing] = React.useState(false);
    const navigate = useNavigate();

    const fetchCoinData = React.useCallback(async () => {
        setLoading(true);
        setError(null);
        try {
            const response = await fetch(`https://api.coingecko.com/api/v3/coins/markets?vs_currency=${currency}&order=market_cap_desc&per_page=250&page=1&sparkline=false`);
            if (!response.ok) {
                throw new Error('Failed to fetch data from CoinGecko API');
            }
            const data: CryptoCoin[] = await response.json();
            setCoins(data);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setLoading(false);
            setIsRefreshing(false);
        }
    }, [currency]);

    React.useEffect(() => {
        fetchCoinData();
        const intervalId = setInterval(() => {
            setIsRefreshing(true);
            fetchCoinData();
        }, 30000);

        return () => clearInterval(intervalId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [currency]);
    
    const sortedAndFilteredCoins = React.useMemo(() => {
        return coins
            .filter(coin =>
                coin.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                coin.symbol.toLowerCase().includes(searchTerm.toLowerCase())
            )
            .sort((a, b) => {
                const valA = a[sortKey];
                const valB = b[sortKey];
                if (valA === null) return 1;
                if (valB === null) return -1;
                if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
                if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
                return 0;
            });
    }, [coins, searchTerm, sortKey, sortOrder]);

    const currencySymbol = React.useMemo(() => (currency === 'usd' ? '$' : 'R$'), [currency]);

    const CoinCard = ({ coin, currencySymbol }: { coin: CryptoCoin; currencySymbol: string }) => {
        const isPositive = (coin.price_change_percentage_24h || 0) >= 0;
        return (
            <div
                key={coin.id}
                className="bg-white dark:bg-slate-900 rounded-lg p-4 shadow-sm dark:shadow-none cursor-pointer hover:scale-105 hover:shadow-lg dark:hover:shadow-purple-500/10 transition-all duration-200"
                onClick={() => navigate(`/trading/${coin.symbol.toUpperCase()}-USDT`)}
            >
                <div className="flex items-center space-x-3 mb-3">
                    <img className="h-10 w-10 rounded-full" src={coin.image} alt={coin.name} />
                    <div>
                        <p className="font-bold text-slate-900 dark:text-white truncate">{coin.name}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{coin.symbol.toUpperCase()}</p>
                    </div>
                </div>
                <div>
                    <p className="text-lg font-semibold text-slate-900 dark:text-white">{currencySymbol}{coin.current_price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 6 })}</p>
                    <p className={`font-semibold ${isPositive ? 'text-green-500 dark:text-green-400' : 'text-red-500 dark:text-red-400'}`}>
                        {isPositive ? '+' : ''}{(coin.price_change_percentage_24h || 0).toFixed(2)}%
                    </p>
                </div>
            </div>
        );
    };

    return (
        <div className="p-4 max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold mb-6 flex items-center">
                Markets
                {isRefreshing && <div className="ml-3 w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>}
            </h1>

            <div className="flex flex-col md:flex-row gap-4 mb-4">
                <div className="relative flex-grow">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500" size={20} />
                    <input
                        type="text"
                        placeholder="Search coins..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full bg-white dark:bg-slate-900 border border-gray-300 dark:border-slate-800 rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                    <select
                        value={currency}
                        onChange={(e) => setCurrency(e.target.value as 'usd' | 'brl')}
                        className="bg-white dark:bg-slate-900 border border-gray-300 dark:border-slate-800 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500 h-full"
                    >
                        <option value="usd">USD</option>
                        <option value="brl">BRL</option>
                    </select>

                   <select
                       value={`${sortKey}-${sortOrder}`}
                       onChange={(e) => {
                           const [key, order] = e.target.value.split('-');
                           setSortKey(key as SortKey);
                           setSortOrder(order as 'asc' | 'desc');
                       }}
                       className="bg-white dark:bg-slate-900 border border-gray-300 dark:border-slate-800 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500 h-full text-sm"
                   >
                       <option value="market_cap-desc">Market Cap ↓</option>
                       <option value="market_cap-asc">Market Cap ↑</option>
                       <option value="current_price-desc">Price ↓</option>
                       <option value="current_price-asc">Price ↑</option>
                       <option value="price_change_percentage_24h-desc">24h % ↓</option>
                       <option value="price_change_percentage_24h-asc">24h % ↑</option>
                   </select>
                    
                     <button onClick={() => { setIsRefreshing(true); fetchCoinData(); }} disabled={isRefreshing} className="bg-white dark:bg-slate-900 border border-gray-300 dark:border-slate-800 rounded-lg p-2 flex items-center justify-center disabled:opacity-50">
                        <RefreshCw size={20} className={isRefreshing ? 'animate-spin' : ''} />
                    </button>
                </div>
            </div>

            {loading && coins.length === 0 ? (
                <div className="text-center py-10">Loading market data...</div>
            ) : error ? (
                <div className="text-center py-10 text-red-400">{error}</div>
            ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                    {sortedAndFilteredCoins.map(coin => (
                        <CoinCard key={coin.id} coin={coin} currencySymbol={currencySymbol} />
                    ))}
                </div>
            )}
        </div>
    );
};

export default MarketsScreen;